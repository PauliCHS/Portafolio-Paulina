#Ejemplo de formulario básico
def main():
    nombre = input("Nombre: ")
    edad = input("Edad: ")
    correo = input("Correo: ")
    print("\n--- Datos ingresados ---")
    print(f"Nombre: {nombre}")
    print(f"Edad: {edad}")
    print(f"Correo: {correo}")

if __name__ == "__main__":
    main()
