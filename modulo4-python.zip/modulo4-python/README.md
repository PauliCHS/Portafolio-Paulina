# Módulo 4 - Python básico
Contiene scripts simples para demostrar conceptos básicos de Python.

Cómo ejecutar:
1. Abrir terminal en esta carpeta.
2. Activar entorno (opcional).
3. Ejecutar `python archivo.py`

Aquí podrás encontrar:
-Agenda para contactos
-calculadora de áreas geométricas
-Conversor de temperatura y tipos de moneda
-Ejemplo de formumario básico
-Tabla para multiplicar
